//
//  Tuple.cpp
//  LAB3
//
//  Created by Josh Spencer on 3/8/18.
//  Copyright © 2018 Josh Spencer. All rights reserved.
//

#include "Tuple.h"
