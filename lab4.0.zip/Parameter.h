//
/*
 *  Must have a toString function
 */

#pragma once

#include <iostream>
#include <vector>

using namespace std;

class Parameter{
public:
    Parameter(){}
    ~Parameter(){}
    
private:
    
};
