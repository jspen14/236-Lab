//

#pragma once
#include <string>
#include <vector>
#include <set>
#include "Scheme.h"
#include "Tuple.h"
#include <iostream>

using namespace std;

class Relation{
public:
    void setName(string inputName);
    
    void addColHeader(Scheme inputColHeader);
    
    void addTuple(Tuple inputRow);
    
    void addAllRows(set<Tuple> rowsToAdd);
    
    string getName();
    
    Scheme getColHeader(); // possibly edit to return value at index?
    
    set<Tuple> getRows(); //possibly edit to return single row?
    
    Relation selectIndexValue(int index, string value);
    
    Relation selectIndexIndex(int index1, int index2);
    
    Relation project(vector<int> indicesOfVariables);
    
    Relation rename(vector<string> namesOfVariables);
    
private:
    string name;
    Scheme colHeader;
    set<Tuple> rows;
};
/* Relation_hpp */
