//
//  Interpreter.cpp
//  LAB3
//
//  Created by Josh Spencer on 3/12/18.
//  Copyright © 2018 Josh Spencer. All rights reserved.
//

#include "Interpreter.h"


void Interpreter::interpret(DatalogProgram dp){
    Database database;
    createRelations(dp.getSchemeList(), database);
    populateRelationsFromFacts(dp.getFactList(), database);
    evaluateQueries(dp.getQueryList(), database);
}

void Interpreter::createRelations(vector<Predicate> schemes, Database &database){
    for (unsigned int i = 0; i<schemes.size(); i++){
        Relation relation;
        vector<string> parametersInScheme;
        Scheme colHeader;
        
        relation.setName(schemes[i].getName());
        
        parametersInScheme = schemes[i].getParamList();
        for(unsigned int j = 0; j<parametersInScheme.size(); j++){
            colHeader.push_back(parametersInScheme[j]);
        }
        
        relation.addColHeader(colHeader);
        
        database.addRelation(relation.getName(), relation);
    }
}

void Interpreter::populateRelationsFromFacts(vector<Predicate> facts, Database &database){
    //forEach fact in Facts
        //Find the matching relation by matching facts name and relation name from database
        //Once relation found, add a tuple by iterating through each
    // map<string,Relation> relations;
    // relations = database.getRelationsMap();
    
    for (unsigned int i = 0; i<facts.size(); i++){
        Tuple tuple;
        vector<string> parametersInFact;
        
        parametersInFact = facts[i].getParamList();
        
        for(unsigned int j = 0; j<parametersInFact.size(); j++){
            tuple.push_back(parametersInFact[j]);
        }
        
        // duplicate check tuple
       
        database.getRelationsMap()[facts[i].getName()].addTuple(tuple);
       
    }
}

void Interpreter::evaluateQueries(vector<Predicate> queries, Database database){

    for (unsigned int i = 0; i < queries.size(); i++){
        Relation relation;
        Relation editedRelation;
        vector<string> queryParams;
        set<Tuple> rows;
        
        relation = database.getRelationsMap()[queries[i].getName()]; // Step 1
        queryParams = queries[i].getParamList();
        //rows.insert(relation.getRows().begin(), relation.getRows().end());
        
        editedRelation = relation;
        
        for (unsigned int j = 0; j < queryParams.size(); j++){
            if (queryParams[j].at(0) == '\''){
                editedRelation = editedRelation.selectIndexValue(j, queryParams[j]);
            }
            else{
                for(unsigned int k = j+1; k < queryParams.size(); k++){
                    if (queryParams[j] == queryParams[k]){
                        editedRelation = editedRelation.selectIndexIndex(k, j);
                    }
                }
            }
        }
        
        editedRelation = evaluateQueriesProject(queryParams, editedRelation);
        editedRelation = evaluateQueriesRename(queryParams, editedRelation);
        printEditedRelation(queries[i], editedRelation);
    }
}

Relation Interpreter::evaluateQueriesProject(vector<string> queryParams, Relation editedRelation){
    // check for duplicates here
    vector<int> indicesOfVariables;
    vector<string> variablesVector;
    
    for (unsigned int i = 0; i<queryParams.size(); i++){
        
        if(queryParams[i].at(0) != '\'' && !found(variablesVector, queryParams[i])){
            variablesVector.push_back(queryParams[i]);
            indicesOfVariables.push_back(i);
        }
    }
    
    return editedRelation.project(indicesOfVariables);
}

Relation Interpreter::evaluateQueriesRename(vector<string> queryParams, Relation editedRelation){
    vector<string> variableQueryParams;
    
    for (unsigned int i = 0; i<queryParams.size(); i++){
        if(queryParams[i].at(0) != '\''){
            variableQueryParams.push_back(queryParams[i]);
        }
    }
    
    
    return editedRelation.rename(variableQueryParams);
}

void Interpreter::printEditedRelation(Predicate query, Relation editedRelation){
    cout << query.getName() << "(";
    vector<string> queryParams = query.getParamList();
    set<Tuple> relationRows;
    vector<string> nonRepeatedQueryParams;
    

    for (unsigned int i = 0; i < queryParams.size(); i++){
        cout << queryParams[i];
        
        if (i != queryParams.size()-1){
            cout << ",";
        }
    }
    
    cout << ")? ";
    
//    for (int i = 0; i < queryParams.size()-1; i++){
//        if (queryParams[i] != queryParams[i+1]){
//            nonRepeatedQueryParams.push_back(queryParams[i]);
//        }
//    }
    
    if (editedRelation.getRows().size() == 0) {
        cout << "No" << endl;
    }
    else{
        cout << "Yes(" << editedRelation.getRows().size() << ")" << endl;
        printEditedRelation2(editedRelation, queryParams, relationRows);
    }
}

void Interpreter::printEditedRelation2(Relation editedRelation, vector<string> queryParams, set<Tuple> relationRows){
    int k = 0;
    set<Tuple> rows = editedRelation.getRows();
    
    if (!allConstants(queryParams)){
        for (auto row:rows){
            
            k = 0;
            cout << " ";
            for (unsigned int j = 0; k < row.size(); j++){
                if (queryParams[j].at(0) != '\'' && queryParams[j] != queryParams[j+1]){
                    if (row[0].at(0) != '\''){
                        break;
                    }
                    cout << " " << queryParams[j] << "=" << row[k];
                    k++;
                    if (k < row.size()){ // this is the last thing to fix
                        cout << ",";
                    }
                }
            }
            cout << endl;
            
        }
    }
}

bool Interpreter::allConstants(vector<string> queryParams){
    bool allConst = true;
    
    for (int i = 0; i < queryParams.size(); i++){
        if (queryParams[i].at(0) != '\''){
            allConst = false;
        }
    }
    
    return allConst;
}

bool Interpreter::found(vector<string> variableQueryParams, string possibleInput){
    for (unsigned int i=0; i < variableQueryParams.size(); i++){
        if (variableQueryParams[i] == possibleInput){
            return true;
        }
    }
    
    return false;
}



