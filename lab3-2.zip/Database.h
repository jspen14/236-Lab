//
//  Database.hpp
//  LAB3
//
//  Created by Josh Spencer on 3/8/18.
//  Copyright © 2018 Josh Spencer. All rights reserved.
//

#pragma once
#include <map>
#include <string>
#include "Relation.h"
#include "Scheme.h"
#include "Tuple.h"

using namespace std;

class Database{
public:
    void addRelation(string name, Relation relation);
    
    map<string,Relation>& getRelationsMap();
    
private:
    map<string, Relation> relationsMap;
};
/* Database_hpp */
