//
//  Scheme.hpp
//  LAB3
//
//  Created by Josh Spencer on 3/8/18.
//  Copyright © 2018 Josh Spencer. All rights reserved.
//

#pragma once /* Scheme_hpp */
#include <vector>
#include <string>

using namespace std;

class Scheme : public vector<string>{
public:
private:
};
