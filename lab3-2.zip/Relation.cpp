//
//  Relation.cpp
//  LAB3
//
//  Created by Josh Spencer on 3/8/18.
//  Copyright © 2018 Josh Spencer. All rights reserved.
//

#include "Relation.h"

void Relation::setName(string inputName){
    name = inputName;
}

void Relation::addColHeader(Scheme inputColHeader){
    colHeader = inputColHeader;
}

void Relation::addTuple(Tuple inputRow){
    rows.insert(inputRow);
}

void Relation::addAllRows(set<Tuple> rowsToAdd){
    rows = rowsToAdd;
}

string Relation::getName(){
    return name;
}

Scheme Relation::getColHeader(){
    return colHeader;
}

set<Tuple> Relation::getRows(){
    return rows;
}

Relation Relation::selectIndexValue(int index, string value){
    Relation relationToReturn;
    set<Tuple> rows;
    relationToReturn.setName(this->getName());
    relationToReturn.addColHeader(this->getColHeader());
    
    rows = this->getRows();
    
    for (auto row:rows) {
        if(row[index] == value){
            relationToReturn.addTuple(row);
        }
    }

    return relationToReturn;
}

Relation Relation::selectIndexIndex(int index1, int index2){
    Relation relationToReturn;
    set<Tuple> rows;
    relationToReturn.setName(this->getName());
    relationToReturn.addColHeader(this->getColHeader());
    
    
    rows = this->getRows();
    
    for (auto row:rows) {
        if(row[index1] == row[index2]){
            relationToReturn.addTuple(row);
        }
    }
  
    
    return relationToReturn;
}

Relation Relation::project(vector<int> indicesOfVariables){
    Relation relationToReturn;
    set<Tuple> rows;
    Scheme newColHeader;
    
    relationToReturn.setName(this->getName());
    
    if (indicesOfVariables.size() == 0){
        relationToReturn.addColHeader(this->getColHeader());
        relationToReturn.addAllRows(this->getRows());
        return relationToReturn;
    }
    
    for (unsigned int i = 0; i<indicesOfVariables.size(); i++){
        newColHeader.push_back(this->getColHeader()[indicesOfVariables[i]]);
    }
    
    relationToReturn.addColHeader(newColHeader);
    
    rows = this->getRows();
    
    
    for (auto row:rows){
        Tuple tuple;
        for (int j=0; j < indicesOfVariables.size(); j++){
            tuple.push_back(row[indicesOfVariables[j]]);
        }
        
        relationToReturn.addTuple(tuple);
    }
    
//    for (unsigned int i = 0; i < rows.size(); i++){
//        Tuple tuple;
//
////        for (int j =0; j < indicesOfVariables.size(); j++){
////            tuple.push_back(rows[i][indicesOfVariables[j]]);
////        }
////
//        relationToReturn.addTuple(tuple);
//    }
    
    return relationToReturn;
}

Relation Relation::rename(vector<string> namesOfVariables){
    Relation relationToReturn;
    Scheme newColHeader;

    for (unsigned int i=0; i < namesOfVariables.size(); i++){
        newColHeader.push_back(namesOfVariables[i]);
    }
    
    relationToReturn.setName(this->getName());
    relationToReturn.addColHeader(newColHeader);
    relationToReturn.addAllRows(this->getRows());
    
    return relationToReturn;
}
