//
//  Tuple.hpp
//  LAB3
//
//  Created by Josh Spencer on 3/8/18.
//  Copyright © 2018 Josh Spencer. All rights reserved.
//

#pragma once/* Tuple_hpp */
#include <vector>
#include <string>

using namespace std;

class Tuple: public vector<string>{
public:
private:
};
